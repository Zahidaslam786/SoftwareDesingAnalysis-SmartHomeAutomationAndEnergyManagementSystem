import java.util.ArrayList;
import java.util.List;


interface EnvironmentSensor {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers();
}


class EnvironmentalSensor implements EnvironmentSensor {
    private List<Observer> observers = new ArrayList<>();
    private String status;

    public void setStatus(String status) {
        this.status = status;
        notifyObservers();
    }

    public String getStatus() {
        return status;
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(status);
        }
    }
}


interface Observer {
    void update(String status);
}


class LightingSystem implements Observer {
    @Override
    public void update(String status) {
        System.out.println("Lighting system updated: " + status);
    }
}


public class Main {
    public static void main(String[] args) {
        EnvironmentalSensor sensor = new EnvironmentalSensor();
        LightingSystem lighting = new LightingSystem();

        sensor.registerObserver(lighting);
        sensor.setStatus("Temperature: 25°C");
    }
}
