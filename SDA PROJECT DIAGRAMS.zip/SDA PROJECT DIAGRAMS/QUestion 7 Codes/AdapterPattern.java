
interface SmartDeviceAPI {
    void connectDevice();
}


class ThirdPartyDevice {
    public void establishConnection() {
        System.out.println("Third-party device connected successfully.");
    }
}

class DeviceAdapter implements SmartDeviceAPI {
    private ThirdPartyDevice thirdPartyDevice;

    public DeviceAdapter(ThirdPartyDevice thirdPartyDevice) {
        this.thirdPartyDevice = thirdPartyDevice;
    }

    @Override
    public void connectDevice() {
        thirdPartyDevice.establishConnection();
    }
}

public class Main {
    public static void main(String[] args) {
        ThirdPartyDevice thirdPartyDevice = new ThirdPartyDevice();
        SmartDeviceAPI adapter = new DeviceAdapter(thirdPartyDevice);
        adapter.connectDevice();
    }
}
