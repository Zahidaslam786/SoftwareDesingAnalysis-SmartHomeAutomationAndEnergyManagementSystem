public class Main {
   
    static class EnergyManagementController {
        private static EnergyManagementController instance;
 
        private EnergyManagementController() {
            System.out.println("Energy Management Controller Initialized");
        }

        public static synchronized EnergyManagementController getInstance() {
            if (instance == null) {
                instance = new EnergyManagementController();
            }
            return instance;
        }
        
        public void optimizeEnergy() {
            System.out.println("Optimizing energy usage...");
        }
    }

    public static void main(String[] args) {
        EnergyManagementController controller = EnergyManagementController.getInstance();
        controller.optimizeEnergy();
    }
}

